package com.capgemini.xyz.ui;

import java.util.Scanner;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.dao.LoanDAO;
import com.capgemini.xyz.service.ILoanService;
import com.capgemini.xyz.service.LoanService;

public class ExecuterMain {

	public static void main(String[] args) {
		ILoanService service=new LoanService();
		System.out.println("XYZ Finance Company Welcomes You");
		Scanner sc=new Scanner(System.in);
		System.out.println("enter your choice");
		System.out.println("1. Register Customer");
		System.out.println("2.Exit");
		int index=sc.nextInt();
		switch(index) {
		case 1: System.out.println("Register Customer");
		System.out.println("Enter the customer Details");
		System.out.println("Enter Customer Name");
		String custName=sc.next();
		System.out.println("Enter Address");
		String address=sc.next();
		System.out.println("Enter email");
		String  email=sc.next();
		System.out.println("Enter the Mobile Number");
		long mobile=sc.nextLong();
		long custID=service.insertCust(new Customer(custName, address, email, mobile));
		System.out.println("Customer InformationSaved Successfully");
		System.out.println("Your Customer Id is:-  "+custID);
		System.out.println("Do you wish to apply for loan?(YES/NO)");
		String answer=sc.next();
		if(answer.equalsIgnoreCase("yes")) {
			System.out.println("Enter the Loan Amount");
			double loanAmount=sc.nextDouble();
			System.out.println("Enter the Loan Duration in months");
			int duration=sc.nextInt();
             double emi=service.calculateEMI(loanAmount, duration);
             System.out.println("For Loan Amount"+" "+loanAmount+" "+"and "+(duration/12) +"years of Duration.");
             System.out.println("Your EMI per month will be  "+emi);
             System.out.println("Do you want to apply for loan?(YES/NO)");
             String answer2=sc.next();
             if(answer2.equalsIgnoreCase("yes")) {
            	 long loanId=service.applyLoan(new Loan(loanAmount, custID, duration));
            	 System.out.println("Your Loan request is generated.");
            	 System.out.println("Your Loan Id is"+loanId);
            	 Customer cust =service.showCustDetails(custID);
            	 Loan loan=service.showLoanDetails(loanId);
            	 System.out.println(cust);
            	 System.out.println(loan);
             }
             else {
            	 System.out.println("Thank you for the visit");
             }
		}
		else {
                    System.out.println(custID+" "+service.showCustDetails(custID));
		}
		case 2: System.out.println("exit");
		System.exit(0);
		}


	}

}
