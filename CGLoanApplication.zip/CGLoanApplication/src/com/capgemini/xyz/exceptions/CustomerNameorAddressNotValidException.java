package com.capgemini.xyz.exceptions;

public class CustomerNameorAddressNotValidException extends Exception {

	public CustomerNameorAddressNotValidException() {
		super();
	}

	public CustomerNameorAddressNotValidException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public CustomerNameorAddressNotValidException(String message, Throwable cause) {
		super(message, cause);
	}

	public CustomerNameorAddressNotValidException(String message) {
		super(message);
		}

	public CustomerNameorAddressNotValidException(Throwable cause) {
		super(cause);
	}

}
