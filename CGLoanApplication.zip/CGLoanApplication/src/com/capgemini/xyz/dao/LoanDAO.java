package com.capgemini.xyz.dao;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;

public class LoanDAO implements ILoanDao{

	long LOAN_ID=500;
	public long getCUST_ID() {
		return (long) (Math.random()*1000);
	}
	public long getLOAN_ID() {
		return ++LOAN_ID;
	}
	@Override
	public long insertCust(Customer cust) {
	    cust.setCustId(getCUST_ID());
		customerEntry.put(cust.getCustId(), cust);
	    return cust.getCustId();
	}
	@Override
	public long applyLoan(Loan loan) {
         loan.setLoanID(getLOAN_ID());
	    loanEntry.put(loan.getLoanID(), loan);
         return loan.getLoanID();
	}


	@Override
	public Customer showCustomerDetails(long custId) {
		return customerEntry.get(custId);
	}
	@Override
	public Loan showLoanDetails(long loanId) {
		return loanEntry.get(loanId);
	}
}
