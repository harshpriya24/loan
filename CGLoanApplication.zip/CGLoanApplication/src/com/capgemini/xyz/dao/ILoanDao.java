package com.capgemini.xyz.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;

public interface ILoanDao {
	public HashMap<Long, Loan>loanEntry=new HashMap<Long, Loan>() ;
	public Map<Long, Customer> customerEntry=new HashMap<Long, Customer>();
	public long applyLoan (Loan loan);
	public long insertCust(Customer cust);
	public Customer showCustomerDetails(long custId);
	public Loan showLoanDetails(long loanId);
}
