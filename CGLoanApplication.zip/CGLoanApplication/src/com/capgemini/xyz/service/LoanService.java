package com.capgemini.xyz.service;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.dao.ILoanDao;
import com.capgemini.xyz.dao.LoanDAO;
import com.capgemini.xyz.exceptions.CustomerNameorAddressNotValidException;

public class LoanService implements ILoanService {
   ILoanDao loanDao=new LoanDAO();
   	@Override
	public long applyLoan(Loan loan) {
		return loanDao.applyLoan(loan);
	}
    
	@Override
	public Customer validateCustomer(Customer customer) throws CustomerNameorAddressNotValidException{
		String name=customer.getCustName();
		String address=customer.getAddress();
	 if(name.matches("[A-Z][a-z]+( [A-Z][a-z]") && (address.matches("\\d+\\s+([a-zA-Z]+|[a-zA-Z]+\\s[a-zA-Z]+)")))
			 return customer;
	 else
	  throw new CustomerNameorAddressNotValidException();	 
	}

	@Override
	public long insertCust(Customer cust) {
	return loanDao.insertCust(cust);
	}

	@Override
	public double calculateEMI(double amount, int duration) {
	
		return ((amount*(9.5)*(1+9.5)*duration))/(((1+9.5)*duration)-1);
	}

	@Override
	public Customer showCustDetails(long custID) {
	
		return loanDao.showCustomerDetails(custID);
	}

	@Override
	public Loan showLoanDetails(long loanID) {

		return loanDao.showLoanDetails(loanID);
	}

}
