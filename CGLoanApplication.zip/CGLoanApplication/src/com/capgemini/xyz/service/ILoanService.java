package com.capgemini.xyz.service;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.exceptions.CustomerNameorAddressNotValidException;

public interface ILoanService {
public long applyLoan(Loan loan) ;
public Customer validateCustomer(Customer customer) throws CustomerNameorAddressNotValidException;
public long insertCust(Customer cust);
public double calculateEMI(double amount,int duration);
public Customer showCustDetails(long custID);
public Loan showLoanDetails(long loanID);

}
